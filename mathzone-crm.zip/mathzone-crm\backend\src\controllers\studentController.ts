import { Request, Response } from 'express';
import { prisma } from '../server';
import { AuthRequest } from '../middleware/auth';

export const getStudents = async (req: AuthRequest, res: Response) => {
  try {
    const students = await prisma.student.findMany({
      include: { group: true }
    });
    res.json(students);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch students' });
  }
};

export const createStudent = async (req: AuthRequest, res: Response) => {
  const { name, phone, groupId, balance } = req.body;
  try {
    const student = await prisma.student.create({
      data: {
        name,
        phone,
        groupId: groupId ? parseInt(groupId) : null,
        balance: balance || 0
      }
    });
    res.status(201).json(student);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create student' });
  }
};