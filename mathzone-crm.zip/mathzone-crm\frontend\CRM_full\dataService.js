/* =============================================
   Mathzone CRM — Markazlashgan Data Service (dataService.js)
   ============================================= */

const DataService = {
    get(key, defaultValue = []) {
        try {
            const val = localStorage.getItem(key);
            return val ? JSON.parse(val) : defaultValue;
        } catch (e) {
            console.error(`DataService get error for ${key}:`, e);
            return defaultValue;
        }
    },

    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            // Notify other tabs
            window.dispatchEvent(new CustomEvent('crm-data-changed', { detail: { key } }));
        } catch (e) {
            console.error(`DataService set error for ${key}:`, e);
            if (e.name === 'QuotaExceededError') {
                showToast('Xotira to\'ldi! Backup oling va brauzer keshini tozalang.', 'danger');
            }
        }
    },

    updateStudent(id, updates) {
        const students = this.get('students');
        const index = students.findIndex(s => s.id === id);
        if (index !== -1) {
            students[index] = { 
                ...students[index], 
                ...updates, 
                updatedAt: new Date().toISOString() 
            };
            this.set('students', students);
            return students[index];
        }
        return null;
    },

    addStudent(student) {
        const students = this.get('students');
        students.push(student);
        this.set('students', students);
        return student;
    },

    deleteStudent(id) {
        let students = this.get('students');
        students = students.filter(s => s.id !== id);
        this.set('students', students);
    }
};

// Sanitizer for XSS protection
function sanitizeHTML(str) {
    if (typeof str !== 'string') return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// Improved ID generator
function generateUniqueStudentId() {
    const active = DataService.get('students');
    const archived = DataService.get('archived_students', []);
    const usedIds = new Set([...active.map(s => s.id), ...archived.map(s => s.id)]);

    let id;
    let attempts = 0;
    do {
        id = Date.now().toString().slice(-6) + Math.floor(100 + Math.random() * 900);
        attempts++;
    } while (usedIds.has(parseInt(id)) && attempts < 100);

    return parseInt(id);
}

window.DataService = DataService;
window.sanitizeHTML = sanitizeHTML;
window.generateUniqueStudentId = generateUniqueStudentId;