import { prisma } from '../server';
import { Request } from 'express';

export const logAudit = async (
  req: Request,
  action: string,
  entityType: string,
  entityId?: number,
  oldData?: any,
  newData?: any
) => {
  try {
    const userId = (req as any).user?.id;
    await prisma.auditLog.create({
      data: {
        userId,
        action,
        entityType,
        entityId,
        oldData: oldData ? JSON.parse(JSON.stringify(oldData)) : null,
        newData: newData ? JSON.parse(JSON.stringify(newData)) : null,
        ipAddress: req.ip,
      },
    });
  } catch (error) {
    console.error('Audit log failed:', error);
  }
};
