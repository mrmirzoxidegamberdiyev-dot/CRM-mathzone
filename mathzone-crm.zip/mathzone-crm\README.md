# Mathzone CRM v10.0 - Production Ready

## Quick Start with Docker

```bash
docker-compose up -d
```

Then open `frontend/CRM_full/login.html` with Live Server (port 5500).

Backend API: http://localhost:3000

## Manual Setup

1. Backend:
```bash
cd backend
npm install
npx prisma migrate dev
npm run seed
npm run dev
```

2. Frontend: Open with Live Server.

Demo logins:
- admin / admin123
- reception / 1234
- teacher / 1234
