import express from 'express';
import { authenticateToken, authorizeRoles } from '../middleware/auth';
import { getStudents, createStudent } from '../controllers/studentController';

const router = express.Router();

router.use(authenticateToken);
router.get('/', authorizeRoles(['ADMINISTRATOR', 'RECEPTION']), getStudents);
router.post('/', authorizeRoles(['ADMINISTRATOR', 'RECEPTION']), createStudent);

export default router;