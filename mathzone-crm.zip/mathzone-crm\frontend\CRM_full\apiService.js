/* =============================================
   Mathzone CRM — API Service (Production v11)
   ============================================= */

const API_BASE = 'http://localhost:3000/api';

const getToken = () => {
  if (window.Auth) return Auth.getAccessToken();
  return localStorage.getItem('accessToken');
};

const clearAuthAndRedirect = () => {
  if (window.Auth) Auth.clearAuth();
  else {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('crm_session');
    localStorage.removeItem('profile');
  }
  window.location.href = 'login.html';
};

const refreshAccessToken = async () => {
  if (window.Auth) return Auth.refreshAccessToken();
  const refreshToken = localStorage.getItem('refreshToken');
  if (!refreshToken) return false;
  try {
    const refreshRes = await fetch(`${API_BASE}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    });
    const refreshData = await refreshRes.json();
    if (refreshRes.ok && refreshData.accessToken) {
      localStorage.setItem('accessToken', refreshData.accessToken);
      return true;
    }
  } catch (e) {}
  return false;
};

const apiFetch = async (url, options = {}) => {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE}${url}`, { ...options, headers });

  if (response.status === 401) {
    const refreshed = await refreshAccessToken();
    if (refreshed) return apiFetch(url, options);
    clearAuthAndRedirect();
    return;
  }

  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }

  return response.json();
};

// Students
export const getStudents = () => apiFetch('/students');
export const createStudent = (data) => apiFetch('/students', { method: 'POST', body: JSON.stringify(data) });
export const updateStudent = (id, data) => apiFetch(`/students/${id}`, { method: 'PUT', body: JSON.stringify(data) });
export const deleteStudent = (id) => apiFetch(`/students/${id}`, { method: 'DELETE' });

// Auth
export const login = async (credentials) => {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(credentials)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Login xatosi');
  if (window.Auth) Auth.saveAuth(data);
  else {
    localStorage.setItem('accessToken', data.accessToken);
    localStorage.setItem('refreshToken', data.refreshToken);
    localStorage.setItem('crm_session', JSON.stringify({
      id: data.user.id,
      name: data.user.name,
      role: data.user.role,
      avatar: data.user.avatar,
      loginTime: Date.now()
    }));
  }
  return data;
};

export const refreshToken = (token) => fetch(`${API_BASE}/auth/refresh`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ refreshToken: token })
}).then(r => r.json());

window.API = { getStudents, createStudent, updateStudent, deleteStudent, login };
